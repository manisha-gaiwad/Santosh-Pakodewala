@extends('layouts.layout')


@section('content')
  

    <section class="content-header">
      <h1>Sell Item</h1>
    </section>
<p class="login-box-msg"></p>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Sell Item</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form method="POST" action="{{ route('sell.store') }}"  enctype="multipart/form-data">
             {{ csrf_field() }}
               @method('POST')
              <div style="display:none;">
              
            </div>             
             <div class="box-body">
             
              <input type="hidden" name="date" value="<?php echo(date(" jS \of F Y")); ?>">
               
                 <!-- Item table start -->
                  
                <div class="form-group table-responsive">
                  <table id="myTable" class="table table-condensed-xs">
                    <thead>
                    <tr>
                      <th>#</th>
                      <th>Item Name</th>
                      <th>Quantity</th>
                      <th>Rate</th>
                      <th>Total Price</th>
                    </tr>
                    </thead>

                    <tbody class="add_new_field">
                      <?php for($i = 1; $i <= 1; $i++){ ?>
                        
                      <tr class="item">
                        <td>&nbsp;</td>
                        <td>  
                          <div class="form-group">
                          
                            <div class="input text">
                              <input name="item_name[]" class="form-control" placeholder="Item Name" type="text" id="mastersIteamName">
                            </div>             
                         </div>
                         <p style="color:red">@error('item_name') {{$message}} @enderror</p></td>
                       <td>   
                          <div class="form-group">
                          
                            <div class="input text">
                              <input name="quantity[]" class="form-control amount" placeholder="Quantity" type="text" id="mastersQuantity" >
                            </div>             
                          </div>
                          <p style="color:red">@error('quantity') {{$message}} @enderror</p></td>
                      <td>   
                         <div class="form-group">
                        
                           <div class="input text">
                            <input name="price[]" class="form-control amount" placeholder="Rate" type="text" id="mastersRate">
                           </div>             
                          </div>
                         <p style="color:red">@error('rate') {{$message}} @enderror</p></td>
                     <td>   
                  <div class="form-group">
              
                  <div class="input text">
                    <input name="total_price[]" class="form-control total" placeholder="Total Price" type="text" id="total1">
                  </div>             
                </div>
                <p style="color:red">@error('total_price') {{$message}} @enderror</p></td>
                         
                      </tr>
                    <?php } ?>
                    </tbody>
                    <tfoot>
                      <tr>
                        <td>
                          
                           <label>Adjustment</label>
                           <input type="checkbox" id="myCheck" name="check" value="1"  onclick="myFunction()" >
                             
                           
                        </td>
                        <td>
                          <!-- <label style="position: absolute;top: -20px;">Adjustment Remark</label> -->
                          <textarea name="adjustment_remark"  id="text" style="display:none"></textarea>
                        </td>
                        <td>
                            <label>Net Amount</label>
                           <input name="total" class="form-control netamount pull-right"  placeholder="Net Amount" type="text" id="netamount" >
                        </td>
                      </tr>
                    </tfoot>
                  </table>

                  <input type="button" class="btn  btn-info add-row" value="Add Row">
                  <button type="button" class="btn  btn-danger delete-row">Delete Row</button>
                </div>


                 <!-- item table End -->
        
                
              </div>
              <!-- /.box-body -->
            <div class="box-footer">
            <div class="submit">
            
                <button type="submit" class="btn btn-primary ">Add Item</button>
            </div>          
              </div>
            </form>
          </div>
      </div>
        <!--/.col (left) -->
    
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

@endsection
    
@section('customscripts')

<script src="{{ asset('customAssets/js/calculation.js') }}"></script>
@endsection


   
