 var max = 2;
  $(".add-row").click(function()
  {
  var markup = '<tr><td><input type="checkbox" name="record"></td><td><input name="item_name[]" class="form-control" placeholder="Iteam Name" type="text" id="mastersIteamName"></td><td><input name="quantity[]" class="form-control newquantity" placeholder="Quantity" type="text" id="mastersQuantity"></td><td><input name="price[]" class="form-control newrate" placeholder="Rate" type="text" id="mastersRate"></td><td><input name="total_price[]" class="form-control newproductPrice" placeholder="Tatal Price" type="text" id="mastetotal"></td></tr>';
    max++;
    $("table tbody").append(markup);
  });

  // DELETE add

   $(".delete-row").click(function(){
          $("table tbody").find('input[name="record"]').each(function(){
            if($(this).is(":checked")){
              var exitMaxVal = $('.maxvalue').val();
              var reduceVal = exitMaxVal-1;
              $(this).parents("tr").remove();
              $(".maxvalue").val(reduceVal);
            }
          });
        });

   //cHECKBOX CHECKED
   function myFunction()
{
var checkBox = document.getElementById("myCheck");
var text = document.getElementById("text");
if (checkBox.checked == true)
{
    text.style.display = "block";
} 
else
{
     text.style.display = "none";
}

}  

// REMAINING AMOUNT CALCULATION

$(document).on('change', '#PaidAmount', function (e) {
        let target = e.target;

        var totalamt = parseFloat($('#totalAmount').val())

        var paidamt = parseFloat($('#PaidAmount').val())
        penamt = totalamt - paidamt;
        $('#paindingAmount').val(penamt)

    }) 

